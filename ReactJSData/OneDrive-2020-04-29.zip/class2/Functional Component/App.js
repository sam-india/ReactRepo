import React from "react";
import "./App.css";
import { HelloWorld, Test } from './components/helloWorld';

function App() {
    return <div >
        <
        h1 > App Component < /h1> <
    Test / >
        <
        /div > ;
}

export default App;