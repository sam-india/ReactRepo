import React, { Component } from 'react';

class Footer extends Component {
    state = {}
    render() {
        return ( 
            <div className="jumbotron">
  <h1 className="display-4">Footer!</h1>
  <p className="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
  
</div>
         );
        }
    }

    export default Footer;