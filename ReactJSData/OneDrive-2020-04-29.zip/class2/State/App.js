import React, { useImperativeHandle } from "react";
import "./App.css";
import User from "./components/User";
import 'bootstrap/dist/css/bootstrap.css';

function App() {
    return <div >
        <
        h2 > App Component < /h2>

    <
    User / >

        <
        /div>;
}

export default App;