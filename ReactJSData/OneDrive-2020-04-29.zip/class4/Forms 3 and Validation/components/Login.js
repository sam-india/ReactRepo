import React, { Component } from 'react';

class Login extends Component {
    state = {  }
    render() { 
        return ( 
            <div>Login</div>
         );
    }
}
 
export default Login;