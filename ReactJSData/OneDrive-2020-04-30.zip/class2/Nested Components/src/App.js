import React from 'react';
import logo from './logo.svg';
import './App.css';
import Header from './components/header';
import Navbar from './components/navbar';
import Sidebar from './components/sidebar';
import MainContent from './components/mainContent'
import Footer from './components/footer';

function App() {
    return ( <div>
        <Navbar />
        <Header />
        <div className="row">
            <div className="col-lg-6">
                <Sidebar />
            </div>
            <div className="col-lg-6">
                <MainContent />
            </div>
        </div>
        
        <Footer />
        </ div>
    );
}

export default App;