import { FullTimeEmployee } from './fullTimeEmployee';

const fte = new FullTimeEmployee('Mark', 'Smith', 5000);
fte.fullName();