import React, { Component } from 'react';

class Column extends Component {
    state = {  }
    render() { 
        return ( 
            <React.Fragment>
                <td>1</td>
                <td>Mark</td>
                <td>mark@gmail.com</td>
            </React.Fragment>
         );
    }
}
 
export default Column;