import React, { Component } from 'react';

class Footer extends Component {
    state = {  }
    render() { 
        return ( 
            <div>
                <div className="jumbotron">
  <h1 className="display-4">Footer!</h1>
  <p className="lead">Footer information here.</p>
  
</div>
            </div>
         );
    }
}
 
export default Footer;