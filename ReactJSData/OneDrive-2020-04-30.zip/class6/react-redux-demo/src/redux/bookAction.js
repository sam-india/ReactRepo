import { BUY_BOOK } from './bookTypes';

export const buyBook = () => {
    return {
        type: BUY_BOOK
    }
}