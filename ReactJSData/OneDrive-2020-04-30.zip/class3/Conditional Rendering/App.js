import React from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.css";
import Auth from './components/Auth';

function App() {
    return ( <
        div >
        <
        h2 > App Component < /h2> <
        Auth / >
        <
        /div>
    );
}

export default App;