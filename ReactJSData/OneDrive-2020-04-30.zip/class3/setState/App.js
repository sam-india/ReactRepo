import React from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.css";
import User from "./components/User";
import Counter from './components/Counter';

function App() {
    return ( <
        div >
        <
        h2 > App Component < /h2>  <
        Counter / >
        <
        /div>
    );
}

export default App;