import React, { Component } from 'react';

class MainContent extends Component {
    state = {}
    render() {
        return ( < h1 > This is Main Content < /h1>);
        }
    }

    export default MainContent;