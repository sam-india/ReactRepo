import React from 'react';

export function HelloWorld() {
    return <h1 > Hello World < /h1>
};

{
    /* export function Test() {
        return <h1 > Test Component < /h1>
    } */
}




export const Test = () => < h1 > Test Component < /h1>